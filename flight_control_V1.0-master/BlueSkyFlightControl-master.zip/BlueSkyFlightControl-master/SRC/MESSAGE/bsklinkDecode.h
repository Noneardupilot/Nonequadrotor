#ifndef _BSKLINKDECODE_H_
#define _BSKLINKDECODE_H_

#include "mathTool.h"

void BsklinkDecode(uint8_t data);

#endif
