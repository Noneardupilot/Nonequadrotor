#ifndef _MAVLINKDECODE_H_
#define _MAVLINKDECODE_H_

#include "mathTool.h"

void MavlinkDecode(uint8_t data);

#endif

