#ifndef _SAFECONTROL_H_
#define _SAFECONTROL_H_

#include "mathTool.h"

void SafeControl(void);

#endif



