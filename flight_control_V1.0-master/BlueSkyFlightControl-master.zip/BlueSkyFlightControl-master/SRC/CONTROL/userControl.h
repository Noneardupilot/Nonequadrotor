#ifndef _USERCONTROL_H_
#define _USERCONTROL_H_

#include "mathTool.h"

void UserControl(void);

#endif

