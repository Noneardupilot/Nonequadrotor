#ifndef __CONTROL_TASK_H__
#define __CONTROL_TASK_H__

void ControlTaskCreate(void);

int16_t	GetFlightControlTaskStackRemain(void);

#endif



