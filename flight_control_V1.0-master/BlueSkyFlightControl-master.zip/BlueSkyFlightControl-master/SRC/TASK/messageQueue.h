#ifndef __MESSAGE_QUEUE_H__
#define __MESSAGE_QUEUE_H__

#include "TaskConfig.h"

void MessageQueueCreate(void);

#endif

