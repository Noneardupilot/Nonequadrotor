#ifndef __MESSAGE_TASK_H__
#define __MESSAGE_TASK_H__

void MessageTaskCreate(void);

int16_t	GetMessageTaskStackRemain(void);

#endif




