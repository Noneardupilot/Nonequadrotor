#ifndef __MODULE_TASK_H__
#define __MODULE_TASK_H__

void ModuleTaskCreate(void);
int16_t	GetImuSensorReadTaskStackRemain(void);
int16_t	GetSensorUpdateTaskStackRemain(void);

#endif


