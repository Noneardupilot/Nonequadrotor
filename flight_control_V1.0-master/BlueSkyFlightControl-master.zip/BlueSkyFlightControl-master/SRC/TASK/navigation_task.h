#ifndef __NAVIGATION_TASK_H__
#define __NAVIGATION_TASK_H__


void NavigationTaskCreate(void);

int16_t	GetNavigationTaskStackRemain(void);
int16_t	GetFlightStatusTaskStackRemain(void);

#endif



