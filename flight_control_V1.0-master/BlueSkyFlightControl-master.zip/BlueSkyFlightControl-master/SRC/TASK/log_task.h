#ifndef __LOG_TASK_H__
#define __LOG_TASK_H__

void LogTaskCreate(void);

int16_t	GetLogTaskStackRemain(void);

#endif

