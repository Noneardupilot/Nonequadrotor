#ifndef _DRV_CAN_H
#define _DRV_CAN_H

#include "board.h"

void Can_Open(uint8_t deviceNum);
void CAN1_SendTest(void);

#endif


