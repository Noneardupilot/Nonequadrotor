#ifndef _DECLINATION_H
#define _DECLINATION_H

#include "mathTool.h"

float CompassGetDeclination(float lat, float lon);

#endif

