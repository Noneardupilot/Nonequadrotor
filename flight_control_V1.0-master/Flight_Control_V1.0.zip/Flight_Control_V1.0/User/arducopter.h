#ifndef __ARDUCOPTER__H__
#define __ARDUCOPTER__H__


#include "copter.h"

#endif